const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
} = require("graphql");
const { user: User } = require("../../sequelize/models");
const { comment: Comment } = require("../../sequelize/models");
const { reaction: Reaction } = require("../../sequelize/models");
const { post: Post } = require("../../sequelize/models");
const UserType = require("./user_type");
const CommentType = require("./comment_type");
const ReactionType = require("./reaction-type");

const PostType = new GraphQLObjectType({
  name: "PostType",
  fields: () => ({
    id: { type: GraphQLID },
    img: { type: GraphQLString },
    text: { type: GraphQLString },
    comments: {
      type: new GraphQLList(CommentType),
      resolve(parentValue) {
        return Comment.findAll({ where: { postId: parentValue.id } });
      },
    },
    reactions: {
      type: new GraphQLList(ReactionType),
      resolve(parentValue) {
        return Reaction.findAll({ where: { postId: parentValue.id } });
      },
    },
    // user: {
    //   type: UserType,
    //   resolve(parentValue) {
    //     return User.findById(parentValue.user);
    //   },
    // },
  }),
});
module.exports = PostType;
