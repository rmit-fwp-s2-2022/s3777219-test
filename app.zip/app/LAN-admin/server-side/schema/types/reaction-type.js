const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
} = require("graphql");
const { user: User } = require("../../sequelize/models");
const { comment: Comment } = require("../../sequelize/models");
const { post: Reaction } = require("../../sequelize/models");
const UserType = require("./user_type");
const CommentType = require("./comment_type");

const ReactionType = new GraphQLObjectType({
  name: "ReactionType",
  fields: () => ({
    id: { type: GraphQLID },
    text: { type: GraphQLString },
    // user: {
    //   type: UserType,
    //   resolve(parentValue) {
    //     return User.findById(parentValue.user);
    //   },
    // },
  }),
});
module.exports = ReactionType;
