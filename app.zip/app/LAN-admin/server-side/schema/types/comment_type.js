const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
} = require("graphql");
const { user: User } = require("../../sequelize/models");
const { comment: Comment } = require("../../sequelize/models");
const { post: Post } = require("../../sequelize/models");
const UserType = require("./user_type");
const PostType = require("./post_type");
const CommentType = new GraphQLObjectType({
  name: "CommentType",
  fields: () => ({
    id: { type: GraphQLID },
    content: { type: GraphQLString },

    // user: {
    //   name: "user",
    //   type: UserType,
    //   resolve(parentValue) {
    //     // return User.findById(parentValue.user);
    //   },
    // },
    // post: {
    //   name: "post",
    //   type: PostType,
    //   resolve(parentValue) {
    //     // return Post.findById(parentValue.post);
    //   },
    // },
  }),
});

module.exports = CommentType;
