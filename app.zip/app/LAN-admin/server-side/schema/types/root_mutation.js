const UserType = require("./user_type");
const { user: User } = require("../../sequelize/models");
const { comment: Comment } = require("../../sequelize/models");
const { post: Post } = require("../../sequelize/models");
const bcrypt = require("bcrypt");
const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
  GraphQLSchema,
} = require("graphql");
const PostType = require("./post_type");
const CommentType = require("./comment_type");

const RootMutationType = new GraphQLObjectType({
  name: "RootMutationType",
  description: "The root query type",
  fields: {
    deleteUser: {
      type: UserType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return User.destroy({ where: { id: args.id } });
      },
    },
    updateUser: {
      type: UserType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return User.update({ where: { id: args.id } });
      },
    },
    blockUser: {
      type: UserType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return User.update({ status: "blocked" }, { where: { id: args.id } });
      },
    },
    unBlockUser: {
      type: UserType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return User.update({ status: "" }, { where: { id: args.id } });
      },
    },
    createPost: {
      type: PostType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Post.create({ where: { id: args.id } });
      },
    },
    deletePost: {
      type: PostType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Post.update(
          { text: "", img: "", comments: [] },
          { where: { id: args.id } }
        );
      },
    },
    updatePost: {
      type: PostType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Post.update({ where: { id: args.id } });
      },
    },
    createComment: {
      type: CommentType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Comment.create({ where: { id: args.id } });
      },
    },
    deleteComment: {
      type: CommentType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Comment.destroy({ where: { id: args.id } });
      },
    },
    updateComment: {
      type: CommentType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Comment.update({ where: { id: args.id } });
      },
    },
    login: {
      type: UserType,
      args: {
        email: { type: GraphQLString },
        password: { type: GraphQLString },
      },
      async resolve(parentValue, args) {
        console.log(args);
        const user = await User.findOne({
          where: { email: args.email },
        });
        console.log(user.password);
        const valid = bcrypt.compareSync(args.password, user.password);
        console.log(valid);
        if (valid) {
          return user;
        } else {
          return null;
        }
      },
    },
  },
});

module.exports = RootMutationType;
