const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
} = require("graphql");
const { user: User } = require("../../sequelize/models");
const { comment: Comment } = require("../../sequelize/models");
const { post: Post } = require("../../sequelize/models");
const PostType = require("./post_type");
const CommentType = require("./comment_type");
const UserType = new GraphQLObjectType({
  name: "UserType",
  fields: () => ({
    id: { type: GraphQLID },
    email: { type: GraphQLString },
    username: { type: GraphQLString },
    firstName: { type: GraphQLString },
    lastName: { type: GraphQLString },
    role: { type: GraphQLString },
    status: { type: GraphQLString },
    posts: {
      type: new GraphQLList(PostType),
      resolve(parentValue) {
        return Post.findAll({ userId: parentValue.id });
      },
    },
    comments: {
      type: new GraphQLList(CommentType),
      resolve(parentValue) {
        return Comment.findAll({ userId: parentValue.id });
      },
    },
  }),
});
module.exports = UserType;
