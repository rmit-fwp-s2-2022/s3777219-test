const UserType = require("./user_type");
const { user: User } = require("../../sequelize/models");
const { comment: Comment } = require("../../sequelize/models");
const { post: Post } = require("../../sequelize/models");
const bcrypt = require("bcrypt");
const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
  GraphQLSchema,
} = require("graphql");
const PostType = require("./post_type");
const CommentType = require("./comment_type");

const RootQueryType = new GraphQLObjectType({
  name: "RootQueryType",
  description: "The root query type",
  fields: {
    users: {
      type: new GraphQLList(UserType),
      resolve(parentValue, args) {
        return User.findAll();
      },
    },
    user: {
      type: UserType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return User.findOne({ where: { id: args.id } });
      },
    },
    posts: {
      type: new GraphQLList(PostType),
      resolve(parentValue, args) {
        return Post.findAll();
      },
    },
    post: {
      type: PostType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Post.findOne({ where: { id: args.id } });
      },
    },
    comments: {
      type: new GraphQLList(CommentType),
      resolve(parentValue, args) {
        return Comment.findAll();
      },
    },
    comment: {
      type: CommentType,
      args: { id: { type: GraphQLID } },
      resolve(parentValue, args) {
        return Comment.findOne({ where: { id: args.id } });
      },
    },
  },
});

module.exports = RootQueryType;
