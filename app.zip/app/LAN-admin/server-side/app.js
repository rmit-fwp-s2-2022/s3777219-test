const express = require("express");
const app = express();
const { graphqlHTTP } = require("express-graphql");
const schema = require("./schema/schema");
const countapi = require("countapi-js");
require("dotenv").config();
const { connectDB } = require("./db/connection");
const cors = require("cors");
app.use(express.json());
app.use(cors());
app.use(require("cookie-parser")());
const PORT = process.env.PORT || 8080;
app.get("/", (req, res) => {
  // var ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
  countapi.visits("global").then((result) => {
    console.log(result.value);
  });
  // console.log("new visit", ip);
});
connectDB();
app.use(
  "/graphql",
  graphqlHTTP({
    schema,
    graphiql: true,
  })
);
// app.use("/api", require("./routes"));
app.listen(PORT, () => {
  console.log(`Server is listening on ${PORT}`);
});
