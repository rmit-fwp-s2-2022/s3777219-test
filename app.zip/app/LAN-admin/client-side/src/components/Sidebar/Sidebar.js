import React, { useState, useEffect } from "react";
import { withRouter, Link } from "react-router-dom";
import "./StyleSheets/Sidebar.css";
function Sidebar(props) {
  const [active, setActive] = useState("");
  const [dropdownToggle, setDropDownToggle] = useState(false);
  useEffect(() => {
    setActive(props.location.pathname);
  }, [props.location.pathname, active]);

  return (
    <div
      className="sidebar-container border-right main-sidebar"
      id="sticky-sidebar"
    >
      <nav id="sidebar" className={props.toggleClass}>
        <ul className="list-unstyled components">
          <li
            className={active === "/loop-now-admin/dashboard" ? "active" : null}
          >
            <Link to="/loop-now-admin/dashboard">
              <div className="menu-icon">
                <i className="fa fa-home nav_icon" aria-hidden="true"></i>
              </div>
              <span className="menu-title">Dashboard</span>
            </Link>
          </li>
          <li className={active === "/loop-now-admin/posts" ? "active" : null}>
            <Link to="/loop-now-admin/posts">
              <div className="menu-icon">
                <i
                  className="fa fa-sticky-note nav_icon"
                  aria-hidden="true"
                ></i>
              </div>
              <span className="menu-title">Posts</span>
            </Link>
          </li>
          <li className={active === "/loop-now-admin/users" ? "active" : null}>
            <Link to="/loop-now-admin/users">
              <div className="menu-icon">
                <i className="fa fa-user nav_icon" aria-hidden="true"></i>
              </div>
              <span className="menu-title">Users</span>
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default withRouter(Sidebar);
