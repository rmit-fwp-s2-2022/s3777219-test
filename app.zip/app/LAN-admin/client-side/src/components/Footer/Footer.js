import React, { Component } from "react";
import "./StyleSheets/Footer.css";
class Footer extends Component {
  state = {};
  render() {
    return (
      <footer className="site-footer">
        <div className="footer-inner bg-white">
          <div className="row">
            <div className="col-sm-6">Copyright &copy; 2022 Loop Agile Now</div>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;
