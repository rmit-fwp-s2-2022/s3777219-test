import React, { Component } from "react";
import AreaChart from "./AreaChart";
class ChartSection extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div className="row">
        <div className="col-lg-12">
          <div className="card">
            <div className="card-body">
              <h4 className="box-title">User Post reactions </h4>
            </div>
            <div className="row">
              <div className="col-lg-8">
                <div className="card-body">
                  <AreaChart />
                </div>
              </div>
            </div>
            <div className="card-body"></div>
          </div>
        </div>
      </div>
    );
  }
}

export default ChartSection;
