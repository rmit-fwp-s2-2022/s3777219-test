import React, { Component } from "react";
import DashboardHeaderCard from "./DashboardHeaderCard";

class DashboardHeaderSection extends Component {
  state = {
    count: 0,
  };
  componentDidMount() {
    fetch("https://api.countapi.xyz/hit/mysite.com/visits")
      .then((res) => res.json())
      .then((data) => {
        this.setState({ count: data.value });
      });
  }
  render() {
    return (
      <div className="row">
        <DashboardHeaderCard
          title="Total Visitors"
          count={this.state.count}
          icon={"users"}
          color={"flat-color-3"}
        />
      </div>
    );
  }
}

export default DashboardHeaderSection;
