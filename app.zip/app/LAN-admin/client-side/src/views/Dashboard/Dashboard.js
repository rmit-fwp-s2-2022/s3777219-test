import React, { Component } from "react";
import "./StyleSheets/Dashboard.css";
import DashboardHeaderSection from "./Components/DashboardHeaderSection";

class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div className="main-content-container p-4 container-fluid">
        <div className="right-panel">
          <DashboardHeaderSection />
          {/* <ChartSection /> */}
        </div>
      </div>
    );
  }
}

export default Dashboard;
