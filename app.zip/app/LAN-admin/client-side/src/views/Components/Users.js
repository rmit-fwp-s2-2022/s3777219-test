import React, { Component } from "react";
import TableContainer from "../Components/Table/userTableContainer";

export default class Users extends Component {
  render() {
    return (
      <div className="main-content-container p-4 container-fluid">
        <div className="right-panel">
          <div className="row">
            <div className="col-lg-12">
              <div className="card">
                <div className="row">
                  <div className="col-lg-8">
                    <div className="card-body">
                      <div className="card-body">Users</div>
                      <TableContainer />
                    </div>
                  </div>
                </div>
                <div className="card-body"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
