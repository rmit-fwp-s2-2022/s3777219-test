import React, { Component, Fragment } from "react";
import AlertContainer from "./AlertContainer";
import BadgeContainer from "./BadgeContainer";
import ButtonsContainer from "./ButtonsContainer";
import CardsContainer from "./CardsContainer";
import LoaderContainer from "./LoaderContainer";
import ProgressBarContainer from "./ProgressBarContainer";

export default class TestContainer extends Component {
  render() {
    return (
      <Fragment>
        <AlertContainer />
        <BadgeContainer />
        <ButtonsContainer />
        <CardsContainer />
        <LoaderContainer />
        <ProgressBarContainer />
      </Fragment>
    );
  }
}
