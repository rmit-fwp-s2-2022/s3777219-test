import Table from "react-bootstrap/Table";
import { useQuery, useMutation } from "@apollo/client";
import { Button } from "react-bootstrap";
import {
  deletePost as deletePostQuery,
  getPosts,
} from "../../../graphql/postQueries";
function TableContainer() {
  const { loading, error, data } = useQuery(getPosts);
  const [
    deletePost,
    { data: mutationData, loading: mutationLoading, error: mutationError },
  ] = useMutation(deletePostQuery);
  const deleteHandler = (id) => {
    deletePost({ variables: { id: id } });
    console.log(mutationData, mutationLoading, mutationError);
  };
  return loading ? (
    <div>Loading...</div>
  ) : error ? (
    <div>Error :(</div>
  ) : (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Text</th>
          <th>Author</th>
          <th>Comments</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.users != null
          ? data.users?.map((user) =>
              user?.posts?.map((post, index) => (
                <tr key={index}>
                  {post.text === "" ? null : (
                    <>
                      <td>{index + 1}</td>
                      <td>{post.text}</td>
                      <td>{user.username}</td>
                      <td>{post.comments?.length}</td>
                      <td>
                        <Button
                          onClick={() => deleteHandler(post.id)}
                          variant="danger"
                        >
                          Delete
                        </Button>
                      </td>
                    </>
                  )}
                </tr>
              ))
            )
          : null}
      </tbody>
    </Table>
  );
}

export default TableContainer;
