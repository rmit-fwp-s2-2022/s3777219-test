import Table from "react-bootstrap/Table";
import { blockUser, getUsers, unBlockUser } from "../../../graphql/userQueries";
import { useQuery, useMutation } from "@apollo/client";
import { Button } from "react-bootstrap";
function TableContainer() {
  const { loading, error, data } = useQuery(getUsers);
  const [
    blockUserMutation,
    { data: mutationData, loading: mutationLoading, error: mutationError },
  ] = useMutation(blockUser);
  const [
    unBlockUserMutation,
    {
      data: UBmutationData,
      loading: UBmutationLoading,
      error: UBmutationError,
    },
  ] = useMutation(unBlockUser);
  const blockHandler = (id) => {
    blockUserMutation({ variables: { id: id } });
    console.log(mutationData, mutationLoading, mutationError);
  };
  const unBlockHandler = (id) => {
    unBlockUserMutation({ variables: { id: id } });
    console.log(UBmutationData, UBmutationLoading, UBmutationError);
  };

  return loading ? (
    <div>Loading...</div>
  ) : error ? (
    <div>Error :(</div>
  ) : (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Username</th>
          <th>Email</th>
          <th>Posts</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.users.map((user, index) => (
          <tr key={index}>
            <td>{index + 1}</td>
            <td>{user.firstName}</td>
            <td>{user.lastName}</td>
            <td>{user.username}</td>
            <td>{user.email}</td>
            <td>{user.posts.length}</td>
            <td>
              {user.status === "blocked" ? (
                <Button
                  onClick={() => unBlockHandler(user.id)}
                  variant="success"
                >
                  UnBlock
                </Button>
              ) : (
                <Button onClick={() => blockHandler(user.id)} variant="danger">
                  Block
                </Button>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default TableContainer;

//     <div>
//     <Table striped>
//       <thead>
//         <tr>
//           <th>#</th>
//           <th>First Name</th>
//           <th>Last Name</th>
//           <th>Username</th>
//           <th>Email</th>
//           <th>Actions</th>
//         </tr>
//       </thead>
//       <tbody>
//         <tr>
//           <td>1</td>
//           <td>Mark</td>
//           <td>Otto</td>
//           <td>@mdo</td>
//         </tr>
//         <tr>
//           <td>2</td>
//           <td>Jacob</td>
//           <td>Thornton</td>
//           <td>@fat</td>
//         </tr>
//         <tr>
//           <td>3</td>
//           <td colSpan={2}>Larry the Bird</td>
//           <td>@twitter</td>
//         </tr>
//         <tr>
//           <td>3</td>
//           <td colSpan={2}>Larry the Bird</td>
//           <td>@twitter</td>
//         </tr>
//       </tbody>
//     </Table>
//     </div>
//   );
// }

// export default TableContainer;
