import React from "react";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import { useMutation, useQuery } from "@apollo/client";
import { login } from "../../graphql/userQueries";
export default function Signin(props) {
  const history = useHistory();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [loginQuery, { loading, error, data }] = useMutation(login);
  const AddData = (e) => {
    e.preventDefault();
    loginQuery({ variables: { email: email, password: password } });
    if (!error && data != null) {
      history.push("/dashboard");
    }
  };

  return (
    <div>
      <div className="container my-5">
        <div className="row">
          <div className="col-lg-6 col-12">
            <div className="card h-100">
              <div className="card-body">
                <form className="mx-4">
                  <div className="mb-3">
                    <h3 className="mb-4">LOGIN</h3>

                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      aria-describedby="emailHelp"
                      placeholder="Email Address"
                      name="email"
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="mb-3">
                    <input
                      type="password"
                      placeholder="Password"
                      className="form-control"
                      id="password"
                      onChange={(e) => setPassword(e.target.value)}
                      name="password"
                    />
                  </div>
                  <button
                    type="submit"
                    value="Login"
                    className="btn btn-outline-dark more my-3"
                    onClick={AddData}
                  >
                    LOGIN
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
