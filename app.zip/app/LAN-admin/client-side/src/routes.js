import React from "react";
import { Redirect } from "react-router-dom";

// Layout Types
import { BaseLayout } from "./layouts";
// Route Views
import Dashboard from "./views/Dashboard/Dashboard";
import Posts from "./views/Components/Posts";
import Users from "./views/Components/Users";

var routes = [
  {
    path: "/loop-now-admin",
    exact: true,
    layout: BaseLayout,
    component: () => <Redirect to="/loop-now-admin/dashboard" />,
  },
  {
    path: "/loop-now-admin/dashboard",
    layout: BaseLayout,
    component: Dashboard,
  },

  {
    path: "/loop-now-admin/posts",
    layout: BaseLayout,
    component: Posts,
  },

  {
    path: "/loop-now-admin/users",
    layout: BaseLayout,
    component: Users,
  },
];

export default routes;
