import { gql } from "@apollo/client";
const getPosts = gql`
  query {
    users {
      id
      firstName
      lastName
      username
      email
      posts {
        id
        text
        comments {
          id
        }
        reactions {
          id
        }
      }
      comments {
        id
      }
    }
  }
`;
const deletePost = gql`
  mutation deletePost($id: ID!) {
    deletePost(id: $id) {
      id
    }
  }
`;
export { getPosts, deletePost };
