import { gql } from "@apollo/client";
const getUsers = gql`
  query {
    users {
      id
      firstName
      lastName
      username
      email
      status
      role
      posts {
        id
        text
      }
    }
  }
`;
const login = gql`
  mutation ($email: String, $password: String) {
    login(email: $email, password: $password) {
      email
    }
  }
`;
const blockUser = gql`
  mutation blockUser($id: ID!) {
    blockUser(id: $id) {
      id
      status
    }
  }
`;
const unBlockUser = gql`
  mutation unBlockUser($id: ID!) {
    unBlockUser(id: $id) {
      id
    }
  }
`;
export { getUsers, blockUser, unBlockUser, login };
