import React, { Component } from "react";
import { createBrowserHistory } from "history";
import { Router, Route, Switch } from "react-router-dom";
import Pages from "./views/Pages/Pages";
import Login from "./views/Pages/Login";

import routes from "./routes";
import { useQuery, gql } from "@apollo/client";
class App extends Component {
  state = {};

  render() {
    fetch("http://localhost:8080", {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
    return (
      <div>
        <Router
          basename={process.env.REACT_APP_BASENAME || ""}
          history={browserHistory}
        >
          <Switch>
            <Route path="/login" component={Login} />
            {routes.map((route, index) => {
              return (
                <Route
                  key={index}
                  path={route.path}
                  exact={route.exact}
                  component={(props) => {
                    return (
                      <route.layout {...props}>
                        <route.component {...props} />
                      </route.layout>
                    );
                  }}
                />
              );
            })}
            <Route Redirect to="/PageNotFound" exact component={Pages} />
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;

const browserHistory = createBrowserHistory();
